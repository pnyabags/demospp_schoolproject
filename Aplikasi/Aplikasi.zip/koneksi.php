<?php
// koneksi 
$host     = "localhost";
$username = "root";
$password = "";
$database ="spp_ganteng";

$koneksi = mysqli_connect($host, $username, $password, $database);
?>