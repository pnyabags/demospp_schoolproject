<?php 
include "../template/header.php";

include "../template/function.php";

?>

<body>
    <?php
include "../template/navbar.php";

include "../template/konten.php";


?>


    <script src="../js/js.js"></script>

</body>

</html>